use Discogs;
-- Добавим ограничения, что при удалении записи с таблицы пользователей,исчезнут все его данные с 
-- вонтлиста, предложений и вся его коллекция
-- начнем с предложений о продажах
alter table Sellers
add foreign key (user_id)
REFERENCES Users(id)
on delete CASCADE;
-- продолжим коллекции
alter table Collections
add foreign key (user_id)
REFERENCES Users(id)
on delete CASCADE;
-- Удалим с Вонтлиста
alter table Wantlist
add foreign key (user_id)
REFERENCES Users(id)
on delete CASCADE;
-- если мы удаляем валюту, на которой, то удалим с предложений так же всю запись по этой валюте
alter table Sellers
add FOREIGN key (currency_id)
REFERENCES Currencies(id)
on delete CASCADE;
-- если мы удаляем данные с таблицы Condition, то есть качество продаваемого товара, то поставим по дефолту 0.
-- но при обновлении пусть идет каскадом, ибо весь товар со временем теряет в качестве
-- добавим ключ в Продажи
alter table Sellers
add FOREIGN key (condition_id)
REFERENCES Conditions(id)
on delete set NULL
on update cascade;
-- добавим ключ в Коллекции
alter table Collections
add FOREIGN key (condition_id)
REFERENCES Conditions(id)
on delete set NULL
on update cascade;
-- Так как у нас справочник аудиорелизов всгео мира, то при удалении формата никаких действий производить в 
-- таблице релизов не нужно
alter table Releases
add FOREIGN key (format_id)
REFERENCES Formats(id)
on delete no ACTION
on update CASCADE;
-- стиль без жанра не может существовать, поэтому при удалении жанра так же удаляем стили
alter table Styles
add foreign key (Genre_id)
REFERENCES Genres(id)
on delete CASCADE
on update cascade;
-- так как у нас справочник аудиорелизов всего мира, то при удалении стиля или жанра, никаких действий производить в таблице релизов не нужно
alter table Releases
add foreign key (genre_id)
REFERENCES Genres(id)
on delete no ACTION
on update cascade;
-- аналогично поступаем и со стилями
alter table Releases
add foreign key (style_id)
REFERENCES Styles(id)
on delete no ACTION
on update cascade;
-- аналогичная ситуация и с лэйблами, независимот от его наличия, релиз должен оставаться в основном справочнике
alter table Releases
add FOREIGN key (label_id)
REFERENCES Labels(id)
on delete No action;
on update cascade;
-- с Артистами так же
alter table Releases
add FOREIGN key (artist_id)
REFERENCES Artists(id)
on delete no action;
on update cascade;
-- Свяжем страны с лэйблами, чтобы при удалении страны, она оставалась в справочнике лейблов
alter table Labels
add FOREIGN key (country_id)
REFERENCES Countries(id)
on delete no action;
on update cascade;


