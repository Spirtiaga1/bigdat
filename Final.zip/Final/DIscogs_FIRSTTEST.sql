-- Энциклопедия и сервис по покупке/продаже аудиозаписей на разных носителях среди пользователей интернета, который позволяет вести свою коллекцию в аккаунте,
-- вести свой "вонтлист" (то, что ты хочешь купить) для покупателей, вести свой "селллист" (для продавцов) для продавцов.
use Discogs;
-- Создаем таблицу валют - она необходима для правильного выставления стоимости
create table Currencies (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Currency VARCHAR(100));
-- Заполняем валютами
insert into Currencies values
(default, 'US Dollar ($)'),
(default, 'British Pound (£)'),
(default, 'Canadian Dollar (CA$)'),
(default, 'Australian Dollar (A$)'),
(default, 'Euro');
-- Создаем таблицу состояния - она необходима для описания качества аудионосителя при выставлении стоимости
create table Conditions (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Cond VARCHAR(100));
-- Заполняем валютами
insert into Conditions values
(default, 'Mint (M)'),
(default, 'Near Mint (NM)'),
(default, 'Very Good Plus (VG+)'),
(default, 'Very Good (VG)'),
(default, 'Good Plus (G+)'),
(default, 'Good (G)'),
(default, 'Fair (F)'),
(default, 'Poor (P)');
-- Создаем таблицу форматов носителей аудионосителей
create table Formats (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Form VARCHAR(100));
-- Заполняем все возможные форматы
insert into Formats values
(default, 'Vinyl'),
(default, 'CD'),
(default, 'Cassete'),
(default, 'DVD'),
(default, 'Boxset'),
(default, 'Digital');
-- Создаем таблицу жанров - она необходима для фильтрации и более широкого поиска
create table Genres (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Genre VARCHAR(100));
-- Заполняем жанры
insert into Genres values
(default, 'Rock'),
(default, 'Electronic'),
(default, 'Hip-Hop'),
(default, 'Folk, World & Country'),
(default, 'Jazz');
-- Создаем таблицу стилей - она необходима для фильтрации и более широкого поиска + каждый жанр содержит очень много разных музыкальных стилей
create table Styles (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Genre_id INT, Style VARCHAR(100));
-- Заполняем жанры
insert into Styles values
(default, 1, 'Pop Rock'),
(default, 1, 'Psy Rock'),
(default, 2, 'Ambient'),
(default, 2, 'Trip-Hop'),
(default, 3,'Trap'),
(default, 3,'Thrill-Hop'),
(default, 3,'Fonk'),
(default, 4,'Celtic'),
(default, 4,'Irish Pop'),
(default, 4,'German Brass'),
(default, 5,'Dark Jazz'),
(default, 5,'Modern Jazz');
-- Так же многие собирают музыку по студиям звукозаписи, это так же немаловажный факт. Создадим справочник студий и добавив некоторое описание к каждой из них
create table Labels (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Label Varchar(100), Description text);
-- Добавим значения в таблицу лэйблов
select * from Labels;
alter table Labels add column country_id INT;
update Labels set country_id=4 where id=3;
insert into Labels values
(default, 'Warner Brothers', 'Major label since 1996 Year'),
(default, 'Sony Music', 'japan major label since 1984 Year'),
(default, 'Ninja Tune', 'Alternarive Electronic Label by Coldcut'),
(default, 'Vision Recordings', 'Label by gods of DnB Sound - Noisia'),
(default, 'Project Trendkill','Newcomer by Gridlok, award from 2016');
-- Конечно на каждом из лэйблов выпускаются различные артисты, поэтому необходимо создать базу данных и по ним. Так же добавим описание в свободной форме, чтобы пользователь сервиса мог узнать что-то новоеalter
create table Artists (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Artist Varchar(100), Description text);
-- Добавим значения в таблицу лэйблов
insert into Artists values
(default, 'Linkin Park', 'Rock Band from USA'),
(default, 'Propellerheads', 'Jazz & Breaks project from UK'),
(default, 'Noisia', 'Nietherland Bass project'),
(default, 'Madonna', 'Singer from USA'),
(default, 'The Beatles','Classic');

--  Так как лэйблы, покупатели и продавцы находятся в разных странах, необходимо создать справочник стран.
-- Конечно на каждом из лэйблов выпускаются различные артисты, поэтому необходимо создать базу данных и по ним. Так же добавим описание в свободной форме, чтобы пользователь сервиса мог узнать что-то новоеalter
create table Countries (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, Country Varchar(100));
-- Добавим значения в таблицу лэйблов
insert into Countries values
(default, 'USA'),
(default, 'UK'),
(default, 'Russia'),
(default, 'Germany'),
(default, 'Japan');
-- Далее заведем основную таблицу аудиорелизов.
create table Releases(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY comment 'просто номер строки',
cat VARCHAR(100) comment 'Категорийный номер',
format_id INT comment 'Формат аудионосителя',
r_y year comment 'Год релиза',
style_id INT comment  'Музыкальный стиль',
genre_id INT comment 'Музыкальный жанр',
artist_id int comment 'номер артиста с каталога артистов',
label_id int comment 'музыкальный лэйбл',
title varchar(500) comment 'название релиза',
add_to datetime comment 'дата, когда релиз добавлен в базу'
);
-- так как один и тот же релизх может быть издан на разных аудионосителях, причем его категорийный номер может оставаться уникальным, необходимо задать ограничение и ввести уникальный ключ, связ
-- категорийный номер, лэйбл и формат аудионосителяalter
alter table Releases
add constraint Releases_cat_format_id_label_id_PK Unique Key (cat,format_id,label_id);
-- создадим таблицу пользователей, кто будет регистрироваться в нашей системеalte
create table Users(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY comment 'ключ пользователя',
fullname varchar(100) not null comment 'полное имя пользователя, используемое при отправке или покупке',
nickname varchar(100) not null comment 'ник пользователя, отображаемый другим пользователям',
email varchar(150) not null unique key comment 'почта, уникальная для каждого пользователя',
photo varchar(500) comment 'ссылка на фото профиля с облачка',
created_at datetime default current_timestamp comment 'дата регистрации пользователя'
);
-- добавим адрес доставки
alter table Users add column addres json; 
-- каждый пользователь, независимо от того продавец он или покупатель, может иметь свою собственную коллекцию релизов
-- создадим такую таблицу
create table Collections(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY comment 'ключ таблицы',
user_id int not null comment 'номер пользователя, разумеется может повторяться',
release_id int not null comment 'номер релиза, имеющийся в его коллекции',
condition_id int not null comment 'состояние аудионосителя'
);
-- теперь создадим вонтлист - это база данных пользователей, которые ищут те или иные релизыalter
create table Wantlist(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY comment 'ключ таблицы',
user_id int not null comment 'тот, кто ищет',
release_id int not null comment 'номер релиза, который ищет'
);
-- и конечно создадим таблицу тех, кто продает. Пользователь может быть и продавцом и покупателемalter
create table Sellers(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY comment 'ключ таблицы',
user_id int not null comment 'тот, кто продает',
release_id int not null comment 'номер релиза, который продается',
condition_id int not null comment 'состояние аудионосителя'
);
alter table Sellers add currency_id int not null comment 'айди валюты';
alter table Sellers add column price decimal(10,2);