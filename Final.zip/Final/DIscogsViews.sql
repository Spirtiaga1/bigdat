-- Вывести список артистов и альбомов, имеющихся в продаже с минимальной ценой
create VIEW Market as
(select Artists.artist, Releases.title, MIN(price) from Sellers 
join 
Releases on 
Sellers.release_id=Releases.id
join 
Artists on
Artists.id=Releases.artist_id
group by Sellers.release_id
order by MIN(price));
Select * from Market;

-- Посчитать общий бюджет рынка в каждой валюте
create VIEW Total as 
(select Currencies.currency,sum(price) 
from Sellers
left join Currencies
on Sellers.currency_id=Currencies.id
group by Currencies.id);

Select * from Total;
