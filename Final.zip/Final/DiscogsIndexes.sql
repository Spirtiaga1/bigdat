-- Поиск по названию релиза
create index title_releases_UI on Releases(title);
-- поиск по продавцу в  
create index user_id_Sellers_I on Sellers(user_id);
