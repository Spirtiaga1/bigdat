-- Вывести по имени пользователя список всех его аудионосителей с вонтлиста и коллекции
delimiter //
create procedure stats(fn varchar(100))
begin
select Users.fullname, release_id as 'Want it' 
from Wantlist 
join Users 
on Wantlist.user_id=Users.id 
where Users.fullname = fn
union
select Users.fullname, release_id as 'Have it'
from Collections 
join Users 
on Collections.user_id=Users.id where Users.fullname=fn;
end
//
delimiter ;
call stats('Emerson Grady');

-- Создать процедуру "Покупки-Продажи". На вход принимается айди пользователя-покупателя и значение первичного ключа таблицы Селлерс
-- Процедура добавляет запись в коллекцию и удаляет запись с таблицы Селлерс
delimiter //
create procedure deal(i INT(10), k INT(10))
begin
insert into Collections VALUES (default,i,(select release_id from Sellers where id=k),(select condition_id from Sellers where id=k));
delete from Sellers where id=k;
end
//
delimiter ;
call deal(5,150);
delete from Collections where id=351 or id=352;
select * from Collections;
select * from Sellers;
drop procedure deal;
-- теперь необходимо создать триггер, который при удалении записи из таблицы Sellers 
-- менял бы значение поля CNT- вычитал 1, или же при добавлении записи в 
-- таблицу Селлерс - прибавлял бы 1 к нужному релизу
-- update Releases set CNT= (select COUNT(Collections.release_id) from Collections where Releases.id=Collections.release_id) ; 
delimiter //
CREATE TRIGGER UPD_REL after INSERT ON Sellers
for each row begin
update Releases set CNT=CNT+1 where Releases.id=new.release_id;
end;
end //
delimiter;
delimiter //
CREATE TRIGGER DEL_REL after DELETE ON Sellers
for each row begin
update Releases set CNT=CNT-1 where Releases.id=old.release_id;
end;
end //
delimiter;

insert into Sellers values(default,5,300,3,2,5.69,1,0.65);
select * from Releases;
delete from Sellers where id=151;