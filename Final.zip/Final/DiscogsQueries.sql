use Discogs;
alter table Sellers drop column cnt;
-- Найти топ 5 имен продавцов группы Битлз, и названия их альбомов с самой дешевой стоимостью доставки
select Artists.artist,Users.fullname, Releases.title, Sellers.delivery_price FROM
Sellers JOIN Releases
on Sellers.release_id=Releases.id
JOIN Artists
on Releases.artist_id=Artists.id
JOIN Users on
Users.id=Sellers.user_id
where Artists.Artist='The Beatles'
order by Sellers.delivery_price desc limit 5;

--  вывести имя коллекционера, у которого больше всего записей Битлз, 
select count(release_id)
from Sellers
group by ;

Select Users.fullname,count(Collections.user_id) as Total
from Collections
join Users 
on Users.id=Collections.user_id
join Releases 
on Releases.id=Collections.release_id
join Artists
on Artists.id=Releases.artist_id
where Artists.artist='The Beatles'
GROUP by(Collections.user_id)
order by Total desc Limit 1;





